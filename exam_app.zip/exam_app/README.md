# تطبيق الاختبارات التفاعلي — دليل البدء

## هيكل المشروع
```
exam_app/
├── lib/
│   ├── main.dart                  # نقطة الدخول
│   ├── models/
│   │   └── question.dart          # نموذج السؤال ونتيجة التحقق
│   ├── services/
│   │   └── api_service.dart       # الاتصال بـ OpenAI/Gemini (استخراج + تحقق)
│   ├── screens/
│   │   ├── upload_screen.dart     # رفع PDF واستخراج الأسئلة
│   │   └── quiz_screen.dart       # عرض السؤال + طرق الإجابة الثلاث
│   └── widgets/
│       └── answer_canvas.dart     # لوحة الرسم بالقلم الرقمي
└── pubspec.yaml
```

## خطوات التنفيذ

### 1. تجهيز البيئة
```bash
flutter create exam_app_temp   # فقط لتوليد ملفات المنصات (android/ios)
# انسخ مجلدي android/ و ios/ من المشروع المؤقت إلى مجلد exam_app
cd exam_app
flutter pub get
```

### 2. إعداد مفتاح الـ API (لا تضعه داخل الكود مباشرة في الإنتاج)
```bash
flutter run --dart-define=OPENAI_API_KEY=sk-xxxxxxxx
```
> **الأفضل عمليًا:** أنشئ باك-إند بسيط (Node.js/Express أو FastAPI) يستقبل
> الطلبات من التطبيق، يضيف المفتاح السري من متغيرات البيئة على السيرفر،
> ثم يمرر الطلب إلى OpenAI/Gemini. هذا يمنع تسريب المفتاح من داخل حزمة APK/IPA.

### 3. أذونات المنصات
**Android** (`android/app/src/main/AndroidManifest.xml`):
```xml
<uses-permission android:name="android.permission.CAMERA"/>
<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE"/>
<uses-permission android:name="android.permission.INTERNET"/>
```

**iOS** (`ios/Runner/Info.plist`):
```xml
<key>NSCameraUsageDescription</key>
<string>نحتاج الكاميرا لالتقاط صورة إجابتك</string>
<key>NSPhotoLibraryUsageDescription</key>
<string>نحتاج الوصول للصور لاختيار صورة الإجابة</string>
```

### 4. تسلسل عمل التطبيق (Flow)
1. `UploadScreen`: المستخدم يختار ملف PDF → `syncfusion_flutter_pdf` يستخرج
   النص الخام محليًا (سريع ومجاني، بدون استهلاك رصيد API).
2. النص الخام يُرسل إلى `ApiService.extractQuestionsFromPdfText()` التي تطلب
   من الموديل تنظيمه في JSON (أسئلة + إجابات نموذجية + تلميحات).
3. الانتقال إلى `QuizScreen` مع قائمة الأسئلة.
4. الطالب يختار طريقة الإجابة (رسم / كتابة / صورة) عبر `SegmentedButton`.
5. عند الضغط "تحقق من الإجابة": يُستدعى `ApiService.verifyAnswer()` الذي
   يرسل الصورة (base64) أو النص إلى موديل Vision، ويقارنها بالإجابة النموذجية.
6. حسب النتيجة: إشعار نجاح + انتقال تلقائي، أو رسالة خطأ + خيار عرض التلميح.

### 5. نقاط تحتاج تخصيصًا لاحقًا
- استبدال الاستدعاء المباشر لـ OpenAI بباك-إند وسيط (أمان المفتاح).
- إضافة تخزين محلي (Hive/SQLite) لحفظ تقدم الطالب بين الجلسات.
- دعم Gemini كبديل جاهز (النموذج المعلّق أسفل `api_service.dart`).
- ضبط عدد محاولات الإعادة المسموح بها لكل سؤال قبل كشف الإجابة كاملة.
- إضافة شريط تقدم عام (Progress Bar) أعلى `QuizScreen`.

### 6. أوامر التشغيل السريعة
```bash
flutter pub get
flutter run --dart-define=OPENAI_API_KEY=your_key_here
```
