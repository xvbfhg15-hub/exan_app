import 'package:flutter/material.dart';
import 'screens/upload_screen.dart';

void main() {
  runApp(const ExamApp());
}

class ExamApp extends StatelessWidget {
  const ExamApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'تطبيق الاختبارات التفاعلي',
      debugShowCheckedModeBanner: false,
      locale: const Locale('ar'),
      theme: ThemeData(
        primarySwatch: Colors.indigo,
        useMaterial3: true,
        fontFamily: 'Cairo', // أضف الخط في pubspec.yaml إن رغبت بخط عربي مخصص
      ),
      home: const UploadScreen(),
    );
  }
}
