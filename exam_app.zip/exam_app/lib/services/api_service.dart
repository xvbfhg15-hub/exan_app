import 'dart:convert';
import 'dart:io';
import 'package:dio/dio.dart';
import '../models/question.dart';

/// طبقة الاتصال بالذكاء الاصطناعي (OpenAI أو Gemini)
/// -- ملاحظة أمان مهمة: لا تضع مفتاح الـ API مباشرة داخل تطبيق الموبايل في بيئة
/// الإنتاج. الحل الصحيح هو تمرير الطلبات عبر باك-إند وسيط (Node/Python) يخفي
/// المفتاح. هنا نوضح الاستدعاء المباشر لأغراض التطوير والتجربة فقط.
class ApiService {
  // غيّر هذا إلى نقطة نهاية الباك-إند الخاص بك في الإنتاج
  static const String _openAiEndpoint =
      'https://api.openai.com/v1/chat/completions';
  static const String _apiKey = String.fromEnvironment('OPENAI_API_KEY');

  final Dio _dio = Dio();

  /// الخطوة 1: استخراج الأسئلة والإجابات النموذجية من نص PDF (بعد سحب النص محليًا
  /// عبر مكتبة syncfusion_flutter_pdf) وتحويلها إلى JSON منظم بواسطة الموديل.
  Future<List<Question>> extractQuestionsFromPdfText(String rawPdfText) async {
    final prompt = '''
استخرج من النص التالي كل الأسئلة وإجاباتها النموذجية، وأعد النتيجة
بصيغة JSON فقط بدون أي شرح إضافي، على الشكل التالي:
[
  {"id": "1", "question": "نص السؤال", "answer": "الإجابة النموذجية", "hint": "تلميح مختصر"}
]

النص:
"""
$rawPdfText
"""
''';

    final response = await _dio.post(
      _openAiEndpoint,
      options: Options(headers: {
        'Authorization': 'Bearer $_apiKey',
        'Content-Type': 'application/json',
      }),
      data: jsonEncode({
        'model': 'gpt-4o-mini',
        'messages': [
          {'role': 'user', 'content': prompt}
        ],
        'temperature': 0,
      }),
    );

    final content = response.data['choices'][0]['message']['content'];
    final List<dynamic> jsonList = jsonDecode(_stripCodeFences(content));
    return jsonList.map((e) => Question.fromJson(e)).toList();
  }

  /// الخطوة 2: التحقق من إجابة الطالب (نص، صورة رسم، أو صورة من الدفتر)
  /// عبر Vision API. الصورة تُرسل بصيغة base64.
  Future<VerificationResult> verifyAnswer({
    required Question question,
    String? typedAnswer,
    File? imageFile, // صورة الرسم أو صورة الدفتر الملتقطة
  }) async {
    final content = <Map<String, dynamic>>[
      {
        'type': 'text',
        'text': '''
السؤال: ${question.questionText}
الإجابة النموذجية: ${question.modelAnswer}

قارن إجابة الطالب (نصًا أو صورة مرفقة) بالإجابة النموذجية، وتجاهل الفروق
الشكلية البسيطة (مسافات، ترقيم، صياغة مرادفة صحيحة علميًا).
أعد النتيجة بصيغة JSON فقط:
{"is_correct": true/false, "extracted_text": "النص المستخرج من إجابة الطالب", "feedback": "ملاحظة قصيرة ومشجعة"}
'''
      }
    ];

    if (typedAnswer != null && typedAnswer.trim().isNotEmpty) {
      content.add({'type': 'text', 'text': 'إجابة الطالب المكتوبة: $typedAnswer'});
    }

    if (imageFile != null) {
      final bytes = await imageFile.readAsBytes();
      final base64Image = base64Encode(bytes);
      content.add({
        'type': 'image_url',
        'image_url': {'url': 'data:image/png;base64,$base64Image'}
      });
    }

    final response = await _dio.post(
      _openAiEndpoint,
      options: Options(headers: {
        'Authorization': 'Bearer $_apiKey',
        'Content-Type': 'application/json',
      }),
      data: jsonEncode({
        'model': 'gpt-4o-mini', // يدعم الرؤية (Vision)
        'messages': [
          {'role': 'user', 'content': content}
        ],
        'temperature': 0,
      }),
    );

    final rawContent = response.data['choices'][0]['message']['content'];
    final jsonMap = jsonDecode(_stripCodeFences(rawContent));
    return VerificationResult.fromJson(jsonMap);
  }

  /// إزالة أسوار الكود ```json ``` إن وُجدت في رد الموديل
  String _stripCodeFences(String text) {
    return text.replaceAll('```json', '').replaceAll('```', '').trim();
  }
}

/*
=====================================================================
 بديل Gemini API (google_generative_ai) - نفس المنطق بصياغة مختلفة:
=====================================================================

final model = GenerativeModel(
  model: 'gemini-1.5-flash',
  apiKey: geminiApiKey,
);

final content = [
  Content.multi([
    TextPart(prompt),
    if (imageFile != null) DataPart('image/png', await imageFile.readAsBytes()),
  ])
];

final response = await model.generateContent(content);
final resultJson = jsonDecode(stripCodeFences(response.text!));
*/
